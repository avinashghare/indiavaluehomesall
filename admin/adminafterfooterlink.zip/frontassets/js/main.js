$(document).ready(function() {
	
	  
	   $('.slider1').bxSlider({
			slideWidth: 250,
			minSlides: 4,
			maxSlides: 4,
			slideMargin: 15
		  });
});