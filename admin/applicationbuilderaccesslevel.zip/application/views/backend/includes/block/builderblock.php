<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editbuilder?id=').$before['builder']->id; ?>">Builder Details</a></li>
<li><a href="<?php echo site_url('site/uploadbuilderimage?id=').$before['builder']->id; ?>">Image</a></li>
</ul>
</div>
</section>