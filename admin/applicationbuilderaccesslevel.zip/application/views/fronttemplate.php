<?php echo $this->load->view('frontend/includes/header'); ?>

<?php echo $this->load->view('frontend/includes/'.$page); ?>

<?php echo $this->load->view('frontend/includes/footer'); ?>